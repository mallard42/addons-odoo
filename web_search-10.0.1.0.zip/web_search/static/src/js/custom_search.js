odoo.define("website_search_autocomplete.custom_search", function (require) {
   "use strict";
    require('website_sale.website_sale');
    $('#search_autocomplete').devbridgeAutocomplete({
        serviceUrl: '/shop/get_suggest',
        onSelect: function (suggestion) {
            window.location.replace(window.location.origin +
                '/shop/product/' + suggestion.data.id + '?search=' + suggestion.value);
        }
    });
});