v1.1.3
======
* Fix blank LESS internal name

v1.1.2
======
* Close button fix

v1.1.1
======
* Permissions for website designer

v1.0
====
* Port to version 10 