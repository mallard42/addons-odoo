# -*- coding: utf-8 -*-
{
    'name': 'Beautiful Snipets',
    'description': 'Theme Mercury snnipets a new animation to your website Awesome Lusk',
    'category': 'Website',
    # 'version':'1.2',
    'author':'wilder, bitodoo',
    'data': [
        'views/assets.xml',
        'views/snippets.xml',
        'views/snippets/mercurio_view.xml',
            ],  
     'depends': [
                'website',        
                ],
            
     'images': [
            'static/description/mercurio-gif.gif',
            ],
    # 'price': 15.00,
    # "license": "Odoo Proprietary License 1",
    'currency': 'EUR',
    # 'live_test_url': 'http://bitodoo.com/'
}


