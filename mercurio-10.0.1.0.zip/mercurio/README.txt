Steps to install theme


3. keep theme and dependent module in addons path.
4. update modules list before installing theme.

